package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/Hello1")
public class DemoServlet extends GenericServlet{

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Calendar c = Calendar.getInstance();
		System.out.println(c);
		PrintWriter pw= res.getWriter();
		//pw.println("<html><body>Hello World!!</body></html>");
		pw.println(c);
	}

}
