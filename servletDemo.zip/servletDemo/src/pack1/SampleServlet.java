package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/hai12")
public class SampleServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		PrintWriter pw = res.getWriter();
		//pw.println("Todays date : "+Calendar.getInstance());
		String Username= req.getParameter("Uname");
		String Password= req.getParameter("Pword");
		pw.println("UserName :"+Username);
		pw.println("Password :"+Password);
		/*Integer age=Integer.parseInt(req.getParameter("age"));
		pw.println("Age :"+age);*/
		String qualification[]=req.getParameterValues("qua");
		for(String s:qualification) {
 		pw.println("Qualificatin :"+s);
		}
		 String query=req.getQueryString();
		 pw.println(query);
}
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException{
		PrintWriter pw=res.getWriter();
		String Username= req.getParameter("Uname");
		String Password= req.getParameter("Pword");
		pw.println("UserName :"+Username);
		pw.println("Password :"+Password);
		Integer age=Integer.parseInt(req.getParameter("age"));
		pw.println("Age :"+age);
		String qualification[]=req.getParameterValues("qua");
		for(String s:qualification)
 		pw.println("Qualificatin :"+s);
		// String query=req.getQueryString();
		//pw.println("<html><body>hello"+Username+"</body></html>");
		/*if(Username.equals("admin") && Password.equals("admin")) {
			pw.println("Login successful");
		}
		else {
			pw.println("Enter correct password");
		}*/
	}
}
